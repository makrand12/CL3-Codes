import json
N=8
inputFile=open("8queen.json")
outputFile = open("out.json","w")
board=json.loads(inputFile.read())
board=board["matrix"]
for i in board:
	print(i)

def solve(numQueens):
    if numQueens == N:
        printBoard()
        return True
    else:
        for i in range(N):
            for j in range(N):
                if(validMove(i,j)):
                    numQueens = numQueens + 1
                    placeQueen(i,j,True)
                    if(solve(numQueens)):
                        return True
                    else:
                        numQueens = numQueens - 1
                        placeQueen(i,j,False)
    return False

def get(x, y):
    if(x<0 or x>7 or y<0 or y>7):
        return False
    if(board[x][y]==1):
        return True
    return False


def validMove(x,y):
    for k in range(N):
        if(get(x,k) or get(k,y) or get(x-1,y-1) or get(x+1,y+1) or get(x-1,y+1) or get(x+1,y-1)):
            return False
    return True

def placeQueen(x,y,validMove):
    if(validMove):
        board[x][y] = 1;
    else:
        board[x][y] = 0;

def printBoard():
    for i in board:
        print(i)
    board["matrix"] = board
    json.dump(board,outputFile)

if __name__ == '__main__':
    solve(0)
